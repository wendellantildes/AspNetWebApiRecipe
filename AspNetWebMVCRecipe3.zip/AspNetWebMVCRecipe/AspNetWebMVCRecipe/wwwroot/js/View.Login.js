﻿$(document).ready(function () {
    $(":input").input(function () {
        verifyFields();
    })

    $('#signinForm').validate({
        rules: {
            Usuario: {
                required: true
            },
            Senha: {
                required: true
            }
        }
    });

});

function onSubmitClicked(button) {
    if ($('#signinForm').valid()) {
        $(button).prop("disabled", "disabled");
        $('#fillValueTextSpan').hide();
        $('#signinTextSpan').hide();
        $('#loadingSpanSpan').show();
        $('#signinForm').submit();
    }
}

function verifyFields() {
    if ($('#signinForm').valid()) {
        $(button).prop("disabled", "disabled");
        $('#fillValueTextSpan').hide();
        $('#signinTextSpan').show();
        $('#loadingSpanSpan').hide();
    }
}

