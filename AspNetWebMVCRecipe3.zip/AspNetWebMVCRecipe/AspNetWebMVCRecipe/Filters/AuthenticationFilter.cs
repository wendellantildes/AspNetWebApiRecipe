﻿using AspNetWebMVCRecipe.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AspNetWebMVCRecipe.Filters
{
    public class AuthenticationFilter : ActionFilterAttribute, IActionFilter
    {

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if(!(filterContext.Controller is LoginController))
            {
                filterContext.Result = new RedirectResult("~/Login/Signin");
            }
            
        }

    }
}
