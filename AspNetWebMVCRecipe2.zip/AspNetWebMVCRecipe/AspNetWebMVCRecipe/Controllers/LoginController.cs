﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AspNetWebMVCRecipe.Models;
using Microsoft.AspNetCore.Mvc;

namespace AspNetWebMVCRecipe.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Signin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Signin(LoginViewModel login)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    return RedirectToAction("Index", "Dashboard", null);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex);
            }
            finally
            {
                login.Senha = "";
            }
            return View(login);
        }
    }
}