﻿$(document).ready(function () {
    $('#signinForm').validate({
        rules: {
            Usuario: {
                required: true
            },
            Senha: {
                required: true
            }
        }
    });

});

function onSubmitClicked(button) {
    if ($('#signinForm').valid()) {
        $(button).prop("disabled", "disabled");
        $('#loginSpan').hide();
        $('#logginginSpan').show();
        $('#signinForm').submit();
    }
}

