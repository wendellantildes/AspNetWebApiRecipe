﻿$(document).ready(function () {
    $(":text").on("input", (function () {
        verifyFields();
    }));

    $('#formSignin').validate({
        errorPlacement: function(error, element) {
            $(element).parent().children("div.form-control-feedback").append(error);
       },

    rules: {
        Email: {
            required: true, 
            email: true
        },
        Password: {
            required: true,
            minlength: 8
        }
    }
    });

});

function onSubmitClicked(button) {
    if ($('#formSignin').valid()) {
        $(button).prop("disabled", "disabled");
        $('#fillValueTextSpan').hide();
        $('#signinTextSpan').hide();
        $('#loadingSpan').show();
        $('#formSignin').submit();
    }
}

function verifyFields() {
    var form = $('#formSignin');
    $(form).validate();
    if ($(form).valid()) {
        $("#signinBtn").prop("disabled", false);
        $('#fillValueTextSpan').hide();
        $('#signinTextSpan').show();
        $('#loadingSpan').hide();
    }else{
        $("#signinBtn").prop("disabled", true);
        $('#fillValueTextSpan').show();
        $('#signinTextSpan').hide();
        $('#loadingSpan').hide();
    }
}

